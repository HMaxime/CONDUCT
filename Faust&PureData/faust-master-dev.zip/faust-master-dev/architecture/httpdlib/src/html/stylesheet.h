#ifndef __STYLESHEET__
#define __STYLESHEET__

extern unsigned char stylesheet[];
extern unsigned int  stylesheet_len;

#endif