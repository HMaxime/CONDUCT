#ifndef __JSSCRIPTS__
#define __JSSCRIPTS__
extern unsigned char jsscripts[];
extern unsigned int  jsscripts_len;
#endif