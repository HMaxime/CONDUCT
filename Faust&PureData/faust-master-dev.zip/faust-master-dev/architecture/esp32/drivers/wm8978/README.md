# WM8978 Object Documentation

This is a driver for the [Wolfson WM8978](https://www.mouser.com/ds/2/76/WM8978_v4.5-1141768.pdf). The documentation of each method of the class can be found in `WM8978.cpp` directly. This file was written based on the information provided in the Codec Specs and on the NuovotonDuino project: <https://github.com/DFRobot/NuvotonDuino>.
